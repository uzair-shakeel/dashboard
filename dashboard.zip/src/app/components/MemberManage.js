import React from 'react'
import { RiArrowLeftRightFill } from "react-icons/ri";
import { RiArrowUpDownLine } from "react-icons/ri";
import { RiDeleteBin6Line } from "react-icons/ri";

const MemberManage = () => {
    return (
        <div>
           
        </div>
    )
}

export default MemberManage